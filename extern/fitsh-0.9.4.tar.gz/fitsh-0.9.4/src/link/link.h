/*****************************************************************************/
/* link.h								     */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* Common header file for including 'linkpoint.h' and 'linkblock.h'	     */
/*****************************************************************************/

#ifndef	__LINK_H_INCLUDED
#define	__LINK_H_INCLUDED	1

#include "linkpoint.h"
#include "linkblock.h"

#endif
                                               

